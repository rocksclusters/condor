
public class simple
{
    public static void main(String[] args)
    {
        if (args.length != 2) {
            System.out.println("Usage: simple.java <sleep-time> <integer>");
        }
        Integer arg_sleep_time;
        Integer arg_input;

        arg_sleep_time = new Integer(args[0]);
        arg_input      = new Integer(args[1]);

        int sleep_time;
        int input;
        
        sleep_time = arg_sleep_time.intValue();
        input      = arg_input.intValue();

        try {
            System.out.println("Thinking really hard for " + sleep_time + " seconds...");
            Thread.sleep(sleep_time * 1000);
            System.out.println("We calculated: " + input * 2);
        } catch (InterruptedException exception) {
            ;
        }
        return;
    }
}


